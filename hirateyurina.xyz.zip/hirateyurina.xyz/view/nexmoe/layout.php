<!DOCTYPE html>
<html>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/gitalk@1/dist/gitalk.css">
 <script src="https://cdn.jsdelivr.net/npm/gitalk@1/dist/gitalk.min.js"></script>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
	<title><?php e(config('site_name'));?> - 私人云服务</title>
	<link rel="shortcut icon" href="//hirateyurina.xyz/theme/favicon.ico">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.1/css/mdui.css">
	<link rel="stylesheet" href="//hirateyurina.xyz/theme/style.css">
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.1/js/mdui.min.js"></script>
</head>
<body class="mdui-theme-primary-blue-grey mdui-theme-accent-blue">
	<header class="nav">
		<div class="navSize">
			<a href="/"><img class="avatar" src="//q.qlogo.cn/g?b=qq&nk=961104003&s=100"/></a>
			<div class="navRight">
				<ul class="navul">
					<li class="navli"><a href="//hirateyurina.gq" target="_blank">博客</a></li>
					<li class="navli"><a href="/login">登陆</a></li>
				</ul>
				<div class="icon"></div>
			</div>
		</div>
	</header>
	<div class="mdui-container">
	    <div class="mdui-container-fluid">
	    <div class="mdui-toolbar nexmoe-item">
			<a href="/"><?php e(config('site_name'));?></a>
			<?php foreach((array)$navs as $n=>$l):?>
			<i class="mdui-icon material-icons mdui-icon-dark" style="margin:0;">chevron_right</i>
			<a href="<?php e($l);?>"><?php e($n);?></a>
			<?php endforeach;?>
			<!--<a href="javascript:;" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>-->
		</div>
		</div>
    	<?php view::section('content');?>
    	<div id="gitalk-container"></div>
  	</div>
<script type="text/javascript">
var gitalk = new Gitalk({
        clientID: '2770fcd1a6441c795865',
        clientSecret: 'f06c736ee64993b4352f7b7d9dfa0c980d6281de',
        repo: 'gitalk',
        owner: 'AgClKawauso',
        admin: ['AgClKawauso'],
        id: 'oneindex',
        distractionFreeMode: true,
        createIssueManually: true
    });
gitalk.render('gitalk-container');
</script>
<body background="//hirateyurina.xyz/theme/background.jpg"

style=" background-repeat:no-repeat ;

background-size:cover; 

background-attachment:fixed;"/>
</body>
</html>