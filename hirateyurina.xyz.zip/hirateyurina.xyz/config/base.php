<?php return array (
  'site_name' => '水獭观察站',
  'password' => 'Hy03202001',
  'style' => 'nexmoe',
  'onedrive_root' => '/share/',
  'cache_type' => 'secache',
  'cache_expire_time' => 3600,
  'cache_refresh_time' => 600,
  'root_path' => '',
  'show' => 
  array (
    'stream' => 
    array (
      0 => 'txt',
    ),
    'image' => 
    array (
      0 => 'bmp',
      1 => 'jpg',
      2 => 'jpeg',
      3 => 'png',
      4 => 'gif',
    ),
    'video5' => 
    array (
      0 => 'mp4',
      1 => 'webm',
      2 => 'mkv',
    ),
    'video' => 
    array (
      0 => '',
    ),
    'video2' => 
    array (
      0 => 'avi',
      1 => 'mpg',
      2 => 'mpeg',
      3 => 'rm',
      4 => 'rmvb',
      5 => 'mov',
      6 => 'wmv',
      7 => 'asf',
      8 => 'ts',
      9 => 'flv',
    ),
    'audio' => 
    array (
      0 => 'ogg',
      1 => 'mp3',
      2 => 'wav',
      3 => 'flac',
      4 => 'm4a',
    ),
    'code' => 
    array (
      0 => 'html',
      1 => 'htm',
      2 => 'php',
      3 => 'css',
      4 => 'go',
      5 => 'java',
      6 => 'js',
      7 => 'json',
      8 => 'txt',
      9 => 'sh',
      10 => 'md',
    ),
    'doc' => 
    array (
      0 => 'csv',
      1 => 'doc',
      2 => 'docx',
      3 => 'odp',
      4 => 'ods',
      5 => 'odt',
      6 => 'pot',
      7 => 'potm',
      8 => 'potx',
      9 => 'pps',
      10 => 'ppsx',
      11 => 'ppsxm',
      12 => 'ppt',
      13 => 'pptm',
      14 => 'pptx',
      15 => 'rtf',
      16 => 'xls',
      17 => 'xlsx',
    ),
  ),
  'images' => 
  array (
    'home' => false,
    'public' => false,
    'exts' => 
    array (
      0 => 'jpg',
      1 => 'png',
      2 => 'gif',
      3 => 'bmp',
    ),
  ),
  'client_secret' => 'evxJQHDM958rafcMO72*^[*',
  'client_id' => '4573ef08-a478-45da-bb31-b9b09ac4ccd9',
  'redirect_uri' => 'https://oneindex.github.io/',
  'refresh_token' => 'OAQABAAAAAAAm-06blBE1TpVMil8KPQ41pEUFzquOx1CfOeuQzoR9_JqxeOxPCCDgKcPWKHe_zEi2F9JpqUXQ9dbCyzpPpQb8IGP8qy1lN-83V4-tTfzN-ptaoN3zQcWKhxSPseFFaTHdUMdnq69WMIBTCVeu6-4HFpXisz_taWH1nGn7BmRKflZh7H-qrhS_0WNR3bRO61CadEH2zKad-Og-kWgyQNa2pONGpxWAW21qzaJeruI72SFoITfwP-YVESm5t-qd4NO7LJyjQMuNwZL0TUmkN137-OcV1GVLIIKMPAFtyTRxl0AoYGagSJpWMjeULybAha6YuZzPsQ9i-jl_9-TbzklgowjE8EMWkeh8j-yravtp0vFdiafvy0a9iSGKKvum0WRx6iw-MFUEDHm7wX8zDmJQaARF5J6wGeKjEGnkivyTJxpONPB-aOxUIFGmvwFpseMWHDwwXiz_mGD4T00R3lLdpBIc8uN4PhwXKThFzQHXMJQBVQJXvlcvX8dc8caFNY-LcHeXXszycl-TjkethT7tfS_qXDDeHVb2X6OBCB0V6-feqhIFqt9AGIL15zBHEHXwacltoLRfD8twfiX8QeBNIhZs6An2nlYO5VjWuaCHyED1yt58jDsFa8clOYzSN0zPMda3iM4cpAlem-1Lz7gf9UH-H7UlSP2rtNh1xxbcCk7awCX9E7lCPrqZtPGxbkwkfs0Z47u70LZnERAGQCqIneuHM8-IA5LQTcULneXfIWoM64IYfA04p7zflFf1VrQD465EUk5QmSCYperDdehNo56UU4kH1XxdrKxTwnPZAHws506PRr6W4Ygxw2J1Mae928gY-ieK8K__jcpouS7vX92gEeNUG0cSBMSOgMr4KSAA',
  'onedrive_hide' => '',
  'onedrive_hotlink' => '*.hirateyurina.xyz;*.hirateyurina.gq',
);